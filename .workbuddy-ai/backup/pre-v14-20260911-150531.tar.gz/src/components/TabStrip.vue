<script setup lang="ts">
import { computed } from 'vue'
import { Close, Plus } from '@element-plus/icons-vue'
import { acquireWebviewSuppression } from '../lib/suppress'
import type { Profile, ProfileStatus } from '../types'

const props = defineProps<{
  profiles: Profile[]
  openTabs: string[]
  activeId: string | null
  statuses: Record<string, ProfileStatus>
  showAiStatus: boolean
}>()

const emit = defineEmits<{
  activate: [id: string]
  close: [id: string]
  create: []
}>()

let releaseMenu: (() => void) | null = null
function onMenuToggle(open: boolean) {
  if (open && !releaseMenu) releaseMenu = acquireWebviewSuppression()
  else if (!open && releaseMenu) {
    releaseMenu()
    releaseMenu = null
  }
}

function statusFor(id: string): ProfileStatus | undefined {
  return props.statuses[id]
}

function tabState(id: string): 'generating' | 'ready' | 'open' {
  const status = statusFor(id)
  if (props.showAiStatus && status?.answer_generating) return 'generating'
  if (props.showAiStatus && status?.answer_ready) return 'ready'
  return 'open'
}

const openProfiles = computed(() =>
  props.openTabs
    .map((id) => props.profiles.find((p) => p.id === id))
    .filter((p): p is Profile => Boolean(p)),
)

const closedProfiles = computed(() => {
  const open = new Set(props.openTabs)
  return props.profiles.filter((p) => !open.has(p.id))
})
</script>

<template>
  <div class="tab-strip">
    <div class="tab-scroll">
      <div
        v-for="profile in openProfiles"
        :key="profile.id"
        class="tab-item"
        :class="{ active: profile.id === activeId, generating: tabState(profile.id) === 'generating', ready: tabState(profile.id) === 'ready' }"
        :title="`${profile.name}${profile.incognito ? ' · 临时账号' : ''}${tabState(profile.id) === 'generating' ? ' · AI 使用中' : tabState(profile.id) === 'ready' ? ' · 回答完成' : ''}`"
        @click="emit('activate', profile.id)"
        @auxclick.middle.prevent="emit('close', profile.id)"
      >
        <span class="tab-dot" :class="`state-${tabState(profile.id)}`" />
        <span class="tab-title">{{ profile.name }}</span>
        <span v-if="tabState(profile.id) === 'generating'" class="tab-ai-loading" aria-label="AI 使用中"><i>.</i><i>.</i><i>.</i></span>
        <span v-else-if="tabState(profile.id) === 'ready'" class="tab-ai-ready">完成</span>
        <span v-if="profile.incognito" class="tab-badge">临时</span>
        <el-icon class="tab-close" title="关闭标签页（登录态保留在磁盘）" @click.stop="emit('close', profile.id)">
          <Close />
        </el-icon>
      </div>

      <el-popover placement="bottom-start" :width="264" trigger="click" @show="onMenuToggle(true)" @hide="onMenuToggle(false)">
        <template #reference>
          <button class="tab-add" title="打开其他账号或新建账号"><el-icon><Plus /></el-icon></button>
        </template>
        <div class="tab-open-menu">
          <template v-if="closedProfiles.length">
            <small class="tab-open-label">未打开的账号</small>
            <button v-for="profile in closedProfiles" :key="profile.id" class="tab-open-item" @click="emit('activate', profile.id)">
              <span class="tab-dot state-open" />
              <span>{{ profile.name }}</span>
              <small v-if="profile.incognito">临时</small>
            </button>
          </template>
          <small v-else class="tab-open-label">所有账号都已打开</small>
          <button class="tab-open-item new" @click="emit('create')">
            <el-icon><Plus /></el-icon><span>新建账号（新标签页打开）</span>
          </button>
        </div>
      </el-popover>
    </div>
  </div>
</template>
