<script setup lang="ts">
import { ref } from 'vue'
import type { BrowserBounds } from '../types'

defineProps<{ empty: boolean }>()
const host = ref<HTMLElement | null>(null)

function getBounds(): BrowserBounds | null {
  const el = host.value
  if (!el) return null
  const rect = el.getBoundingClientRect()
  return { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
}

defineExpose({
  getBounds,
  element: () => host.value,
})
</script>

<template>
  <section ref="host" class="browser-viewport">
    <div v-if="empty" class="empty-state">
      <h2>从左侧账号打开一个标签页</h2>
      <p>每个标签页是一个独立隔离的浏览器容器：Cookie、登录态、指纹互不共享。</p>
    </div>
  </section>
</template>
