export interface Profile {
  id: string
  name: string
  note: string
  avatar: string | null
  default_url: string
  last_url: string
  created_at: string
  order: number
  incognito: boolean
  /** 独立代理，空字符串表示直连 */
  proxy: string
  /** 自定义 User-Agent，空表示系统默认 */
  user_agent: string
  /** IANA 时区，空表示跟随系统 */
  timezone: string
  /** 语言/区域（BCP-47，如 zh-CN），空表示跟随系统 */
  locale: string
  /** 指纹防护（画布/GPU/硬件噪声） */
  fingerprint_guard: boolean
  /** 账号分组，空表示未分组 */
  group: string
}

export interface BrowserBounds {
  x: number
  y: number
  width: number
  height: number
}

/** 新建 / 编辑账号时的隔离设置表单 */
export interface ProfileIsolationSettings {
  name: string
  defaultUrl: string
  incognito: boolean
  proxy: string
  userAgent: string
  timezone: string
  locale: string
  fingerprintGuard: boolean
  group: string
}

/** 从账号页面（chat01.ai）抓到的状态：积分、登录账号名、邮箱、代理出口 */
export interface ProfileStatus {
  credits: string | null
  account: string | null
  email: string | null
  updated_at: string | null
  proxy_ip: string | null
  proxy_region: string | null
  proxy_isp: string | null
  proxy_tested_at: string | null
  /** 后台账号的 AI 回答已完成，等待用户查看 */
  answer_ready: boolean
  /** 当前页面是否检测到 AI 正在生成回答 */
  answer_generating: boolean
  /** 最近一次回答完成时间 */
  answer_finished_at: string | null
}

/** profile:status 事件负载 */
export interface ProfileStatusEventPayload extends ProfileStatus {
  id: string
}

/** 一条下载历史记录（profile:download 事件负载 / get_download_history 元素） */
export interface DownloadEntry {
  id: string
  /** 下载发生时的账号名快照（账号删除后仍可读） */
  profile_name: string
  file_name: string
  path: string
  size: number
  finished_at: string
  success: boolean
}

/** 全局应用设置：下载目录与 chat01 AI 文件自动下载 */
export interface AppSettings {
  download_dir: string
  auto_ai_download: boolean
  /** 自动下载时跳过下载历史中已经成功下载过的同名文件 */
  skip_downloaded_files: boolean
  /** 删除下载文件时是否先显示二次确认 */
  confirm_delete_download: boolean
  /** 下载历史最多保留的记录数 */
  download_history_limit: number
  ai_exts: string
}

export type ThemeId =
  | 'classic'
  | 'claude-light'
  | 'claude-dark'
  | 'midnight-blue'
  | 'graphite'
  | 'glass-blue'
  | 'paper-cream'
  | 'amethyst'
  | 'win11'
  | 'sunset'
  | 'mint-light'


export type BrowserToolbarBuiltinId =
  | 'reload'
  | 'home'
  | 'back'
  | 'forward'
  | 'copy-url'
  | 'overview'
  | 'downloads'
  | 'settings'

export interface BrowserToolbarItem {
  id: BrowserToolbarBuiltinId
  enabled: boolean
}

export interface CustomToolbarButton {
  id: string
  /** 按钮悬浮提示/设置页名称 */
  label: string
  /** 可选 Emoji/短字符图标；留空使用链接图标 */
  icon: string
  /** 点击后在当前账号 WebView 内打开 */
  url: string
  enabled: boolean
}

export interface UiPreferences {
  theme: ThemeId
  density: 'comfortable' | 'compact'
  fontScale: number
  animations: boolean
  /** 自动刷新间隔（秒），0 表示关闭 */
  autoRefreshSeconds: number
  /** 宿主侧工具栏：独立于远程网页，不依赖页面脚本注入 */
  browserToolbarEnabled: boolean
  browserToolbarPosition: 'right' | 'bottom'
  browserToolbarCompact: boolean
  browserToolbarItems: BrowserToolbarItem[]
  customToolbarButtons: CustomToolbarButton[]
  /** 刷新后恢复刷新前的滚动/锚点位置 */
  restorePositionAfterRefresh: boolean
  /** AI 正在生成时暂停自动刷新，避免打断回答 */
  pauseAutoRefreshWhileGenerating: boolean
  /** 标签页显示 AI 生成/完成状态 */
  showTabAiStatus: boolean
  /** 账号状态卡显示登录账号 */
  showStatusAccount: boolean
  /** 账号状态卡显示代理出口 */
  showStatusProxy: boolean
  /** 账号状态卡显示状态更新时间 */
  showStatusUpdatedTime: boolean
  downloadRowsPerPage: number
  downloadView: 'grouped' | 'flat'
}
