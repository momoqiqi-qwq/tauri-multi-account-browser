<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { invoke } from '@tauri-apps/api/core'
import { listen, type UnlistenFn } from '@tauri-apps/api/event'
import { ElMessage, ElMessageBox } from 'element-plus'
import ProfileSidebar from './components/ProfileSidebar.vue'
import StatusSidebar from './components/StatusSidebar.vue'
import TabStrip from './components/TabStrip.vue'
import AddressBar from './components/AddressBar.vue'
import BrowserViewport from './components/BrowserViewport.vue'
import BrowserActionDock from './components/BrowserActionDock.vue'
import ProfileSettingsDialog from './components/ProfileSettingsDialog.vue'
import DownloadsDialog from './components/DownloadsDialog.vue'
import AppPreferencesDialog from './components/AppPreferencesDialog.vue'
import AccountOverviewDialog from './components/AccountOverviewDialog.vue'
import { acquireWebviewSuppression, isSuppressed, registerSuppressionHandler } from './lib/suppress'
import { applyUiPreferences, loadUiPreferences, saveUiPreferences } from './lib/uiPreferences'
import type {
  AppSettings,
  BrowserBounds,
  CustomToolbarButton,
  DownloadEntry,
  Profile,
  ProfileIsolationSettings,
  ProfileStatus,
  ProfileStatusEventPayload,
  UiPreferences,
} from './types'

const profiles = ref<Profile[]>([])
/** 已打开的账号标签页（有序），每个标签页对应一个独立隔离的 WebView */
const openTabs = ref<string[]>([])
const activeId = ref<string | null>(null)
const currentUrl = ref('')
/** 各账号最近一次上报的页面状态（chat01.ai 积分 / 登录账号） */
const statuses = ref<Record<string, ProfileStatus>>({})
/** 账号搜索关键词，同时过滤两个侧边栏 */
const searchQuery = ref('')
/** 全局下载设置（下载目录 / chat01 AI 文件自动下载） */
const dlSettings = ref<AppSettings | null>(null)
/** 下载历史（按账号分组展示在下载对话框） */
const downloadHistory = ref<DownloadEntry[]>([])
const downloadsVisible = ref(false)
const viewport = ref<InstanceType<typeof BrowserViewport> | null>(null)
const profileSettingsVisible = ref(false)
const appSettingsVisible = ref(false)
const accountOverviewVisible = ref(false)
const uiPreferences = ref<UiPreferences>(loadUiPreferences())
applyUiPreferences(uiPreferences.value)
const editingProfile = ref<Profile | null>(null)
/** 两个侧边栏的收起状态，记住用户上一次的选择 */
const profileSidebarCollapsed = ref(localStorage.getItem('mab-profile-sidebar-collapsed') === '1')
const statusSidebarCollapsed = ref(localStorage.getItem('mab-status-sidebar-collapsed') === '1')
let unlistenNavigation: UnlistenFn | undefined
let unlistenStatus: UnlistenFn | undefined
let unlistenDownload: UnlistenFn | undefined
let unlistenDownloadBlocked: UnlistenFn | undefined
let resizeObserver: ResizeObserver | undefined
let autoRefreshTimer: ReturnType<typeof setInterval> | undefined

/** 按名称 / 分组过滤账号，两个侧边栏共用；空关键词返回全部。 */
const filteredProfiles = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()
  if (!query) return profiles.value
  return profiles.value.filter(
    (p) =>
      p.name.toLowerCase().includes(query) || (p.group && p.group.toLowerCase().includes(query)),
  )
})

/** 新建/编辑账号时的分组下拉：按侧边栏出现顺序去重。 */
const profileGroups = computed(() => {
  const seen = new Set<string>()
  const groups: string[] = []
  for (const profile of profiles.value) {
    const group = profile.group.trim()
    if (!group || seen.has(group)) continue
    seen.add(group)
    groups.push(group)
  }
  return groups
})

function persistSidebarState(key: string, collapsed: boolean) {
  localStorage.setItem(key, collapsed ? '1' : '0')
}

function toggleProfileSidebar() {
  profileSidebarCollapsed.value = !profileSidebarCollapsed.value
  persistSidebarState('mab-profile-sidebar-collapsed', profileSidebarCollapsed.value)
}

function toggleStatusSidebar() {
  statusSidebarCollapsed.value = !statusSidebarCollapsed.value
  persistSidebarState('mab-status-sidebar-collapsed', statusSidebarCollapsed.value)
}

function profileById(id: string): Profile | undefined {
  return profiles.value.find((p) => p.id === id)
}

async function loadProfiles() {
  profiles.value = await invoke<Profile[]>('list_profiles')
}

async function loadStatuses() {
  statuses.value = await invoke<Record<string, ProfileStatus>>('get_profile_statuses').catch(
    () => ({}),
  )
}

async function loadSettings() {
  dlSettings.value = await invoke<AppSettings>('get_app_settings').catch(() => null)
}

async function loadDownloadHistory() {
  downloadHistory.value = await invoke<DownloadEntry[]>('get_download_history').catch(() => [])
}

function normalizeExtensionWhitelist(raw: string): string {
  const seen = new Set<string>()
  return raw
    .split(',')
    .map((item) => item.trim().replace(/^\.+/, '').toLowerCase())
    .filter((item) => /^[a-z0-9]{1,12}$/.test(item))
    .filter((item) => {
      if (seen.has(item)) return false
      seen.add(item)
      return true
    })
    .join(',')
}

async function saveSettings(settings: AppSettings) {
  const normalized = { ...settings, ai_exts: normalizeExtensionWhitelist(settings.ai_exts) }
  await invoke('set_app_settings', { settings: normalized })
  dlSettings.value = normalized
  ElMessage.success('下载设置已保存；格式白名单已规范化并即时下发')
}

function updateUiPreferences(preferences: UiPreferences) {
  uiPreferences.value = saveUiPreferences(preferences)
  // 工具栏位置/尺寸改变会直接改变原生子 WebView 的可用矩形。
  // 等 Vue 完成布局后立即同步，避免切换“底部 -> 右侧”时旧 WebView 短暂盖住宿主按钮。
  void nextTick().then(() => syncBounds())
}

function stopAutoRefresh() {
  if (autoRefreshTimer !== undefined) {
    clearInterval(autoRefreshTimer)
    autoRefreshTimer = undefined
  }
}

function startAutoRefresh() {
  stopAutoRefresh()
  const seconds = uiPreferences.value.autoRefreshSeconds
  if (!Number.isFinite(seconds) || seconds <= 0) return
  autoRefreshTimer = setInterval(() => {
    if (!activeId.value || isSuppressed()) return
    if (uiPreferences.value.pauseAutoRefreshWhileGenerating && statuses.value[activeId.value]?.answer_generating) return
    const action = uiPreferences.value.restorePositionAfterRefresh ? 'reload_restore' : 'reload'
    void invoke('browser_action', { id: activeId.value, action }).catch(() => undefined)
  }, Math.max(1, seconds) * 1000)
}

watch(
  () => uiPreferences.value.autoRefreshSeconds,
  () => startAutoRefresh(),
)
watch(activeId, () => startAutoRefresh())

async function refreshStatuses() {
  await invoke('refresh_profile_statuses').catch(() => undefined)
}

function openAccountOverview() {
  accountOverviewVisible.value = true
  void refreshStatuses()
}

async function cloneProfile(profile: Profile) {
  const copy = await invoke<Profile>('clone_profile', { id: profile.id })
  await loadProfiles()
  ElMessage.success(`已创建副本“${copy.name}”，会话数据为全新状态`)
}

async function testProxy(profile: Profile) {
  const loading = ElMessage({
    message: profile.proxy
      ? `正在经代理检测出口 IP：${profile.name}`
      : `正在检测直连出口 IP：${profile.name}`,
    duration: 0,
  })
  try {
    const result = await invoke<{ ok: boolean; ip: string; region: string; isp: string; error: string }>(
      'test_profile_proxy',
      { id: profile.id },
    )
    if (result.ok) {
      ElMessage.success(`${profile.name} 出口：${result.ip}（${result.region} · ${result.isp}）`)
    } else {
      ElMessage.error(`${profile.name} 代理检测失败：${result.error}`)
    }
  } catch (e) {
    ElMessage.error(`代理检测失败：${e}`)
  } finally {
    loading.close()
  }
}

async function activateProfile(id: string) {
  const bounds = viewport.value?.getBounds()
  if (!bounds) return
  if (!openTabs.value.includes(id)) openTabs.value.push(id)
  await invoke('activate_profile', { id, bounds })
  activeId.value = id
  // 有弹层处于打开状态时（例如“+”菜单展开中去侧栏点了账号），保持抑制。
  if (isSuppressed()) {
    await invoke('set_profile_webview_visible', { id, visible: false }).catch(() => undefined)
  }
  const profile = profileById(id)
  currentUrl.value = profile?.last_url || profile?.default_url || 'https://chat01.ai/'
}

async function closeTab(id: string) {
  if (openTabs.value.includes(id)) {
    await invoke('close_profile_tab', { id })
    openTabs.value = openTabs.value.filter((tab) => tab !== id)
  }
  if (activeId.value === id) {
    const fallback = openTabs.value[openTabs.value.length - 1] ?? null
    if (fallback) {
      await activateProfile(fallback)
    } else {
      activeId.value = null
      currentUrl.value = ''
    }
  }
}

async function createProfile(settings: ProfileIsolationSettings) {
  const profile = await invoke<Profile>('create_profile', {
    name: settings.name,
    defaultUrl: settings.defaultUrl,
    incognito: settings.incognito,
    proxy: settings.proxy,
    userAgent: settings.userAgent,
    timezone: settings.timezone,
    locale: settings.locale,
    fingerprintGuard: settings.fingerprintGuard,
    group: settings.group,
  })
  await loadProfiles()
  await nextTick()
  await activateProfile(profile.id)
}

async function updateProfile(id: string, settings: ProfileIsolationSettings) {
  const wasOpen = openTabs.value.includes(id)
  const result = await invoke<{ profile: Profile; needs_reopen: boolean }>('update_profile', {
    id,
    name: settings.name,
    defaultUrl: settings.defaultUrl,
    incognito: settings.incognito,
    proxy: settings.proxy,
    userAgent: settings.userAgent,
    timezone: settings.timezone,
    locale: settings.locale,
    fingerprintGuard: settings.fingerprintGuard,
    group: settings.group,
  })
  await loadProfiles()
  if (result.needs_reopen) {
    // 隔离配置变更后 WebView 已被后端销毁，重新打开以应用新配置。
    openTabs.value = openTabs.value.filter((tab) => tab !== id)
    if (wasOpen) {
      await nextTick()
      await activateProfile(id)
      ElMessage.success('隔离设置已生效：该账号已用新配置重建浏览器')
    } else {
      ElMessage.success('已保存，下次打开该账号时生效')
    }
  } else {
    ElMessage.success('已保存')
  }
}

function openCreateDialog() {
  editingProfile.value = null
  profileSettingsVisible.value = true
}

function openSettingsDialog(profile: Profile) {
  editingProfile.value = profile
  profileSettingsVisible.value = true
}

async function deleteProfile(profile: Profile) {
  const release = acquireWebviewSuppression()
  try {
    await ElMessageBox.confirm(
      `删除“${profile.name}”将同时删除该账号的浏览数据，且不可恢复。`,
      '确认删除',
      { type: 'warning', confirmButtonText: '删除', cancelButtonText: '取消' },
    )
    openTabs.value = openTabs.value.filter((tab) => tab !== profile.id)
    if (activeId.value === profile.id) {
      activeId.value = null
      currentUrl.value = ''
    }
    await invoke('delete_profile', { id: profile.id })
    await loadProfiles()
    // 后端已同步清理该账号的状态缓存，前端保持一致。
    const { [profile.id]: _removed, ...rest } = statuses.value
    statuses.value = rest
    if (!activeId.value && openTabs.value.length > 0) {
      await activateProfile(openTabs.value[openTabs.value.length - 1])
    }
  } finally {
    release()
  }
}

async function clearProfile(profile: Profile) {
  const release = acquireWebviewSuppression()
  try {
    await ElMessageBox.confirm(
      `将清空“${profile.name}”的 Cookie、LocalStorage、IndexedDB 和缓存，所有登录态会退出。`,
      '清除账号数据',
      { type: 'warning' },
    )
    await invoke('clear_profile_data', { id: profile.id })
    openTabs.value = openTabs.value.filter((tab) => tab !== profile.id)
    if (activeId.value === profile.id) {
      const fallback = openTabs.value[openTabs.value.length - 1] ?? null
      if (fallback) {
        await activateProfile(fallback)
      } else {
        activeId.value = null
        currentUrl.value = ''
      }
    }
    ElMessage.success('已清除账号数据，重新打开标签页即为全新会话')
  } finally {
    release()
  }
}

async function navigate(url: string) {
  if (!activeId.value) return
  const value = url.trim()
  if (!value) return
  const normalized = /^https?:\/\//i.test(value) ? value : `https://${value}`
  try {
    await invoke('navigate_profile', { id: activeId.value, url: normalized })
  } catch (error) {
    ElMessage.error(`打开网址失败：${String(error)}`)
  }
}

async function browserAction(action: 'back' | 'forward' | 'reload') {
  if (!activeId.value) return
  await browserActionFor(activeId.value, action)
}

async function goHome() {
  await navigate('https://chat01.ai/')
}

async function copyCurrentUrl() {
  const value = currentUrl.value.trim()
  if (!value) return
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value)
    } else {
      const input = document.createElement('textarea')
      input.value = value
      input.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0;'
      document.body.appendChild(input)
      input.select()
      const copied = document.execCommand('copy')
      input.remove()
      if (!copied) throw new Error('系统剪贴板不可用')
    }
    ElMessage.success('当前网址已复制')
  } catch (error) {
    ElMessage.error(`复制网址失败：${String(error)}`)
  }
}

async function openCustomToolbarButton(button: CustomToolbarButton) {
  if (!activeId.value || !button.url.trim()) return
  await navigate(button.url.trim())
}

/** 对指定账号执行浏览器动作；宿主工具栏和地址栏统一走这里，确保遵守刷新偏好。 */
async function browserActionFor(id: string, action: 'back' | 'forward' | 'reload') {
  const resolvedAction = action === 'reload' && uiPreferences.value.restorePositionAfterRefresh
    ? 'reload_restore'
    : action
  try {
    await invoke('browser_action', { id, action: resolvedAction })
  } catch (error) {
    ElMessage.error(`浏览器操作失败：${String(error)}`)
  }
}

async function syncBounds() {
  const bounds = viewport.value?.getBounds()
  if (!bounds) return
  await invoke('sync_profile_bounds', { bounds, activeId: activeId.value }).catch(() => undefined)
}

/** 拖动窗口大小时 ResizeObserver 会高频触发，合并成停止变化后的一次 IPC。 */
let syncBoundsTimer: ReturnType<typeof setTimeout> | undefined
function scheduleSyncBounds() {
  if (syncBoundsTimer !== undefined) return
  syncBoundsTimer = setTimeout(() => {
    syncBoundsTimer = undefined
    void syncBounds()
  }, 80)
}

async function reorderProfiles(ids: string[]) {
  await invoke('reorder_profiles', { ids })
  await loadProfiles()
}

async function moveProfileToGroup(id: string, group: string, ids: string[]) {
  await invoke('update_profile', { id, group })
  await invoke('reorder_profiles', { ids })
  await loadProfiles()
}

onMounted(async () => {
  registerSuppressionHandler((suppress) => {
    if (!activeId.value) return
    void invoke('set_profile_webview_visible', { id: activeId.value, visible: !suppress }).catch(
      () => undefined,
    )
  })
  await loadProfiles()
  await loadStatuses()
  await loadSettings()
  await loadDownloadHistory()
  unlistenNavigation = await listen<{ id: string; url: string }>('profile:navigated', (event) => {
    const { id, url } = event.payload
    const p = profiles.value.find((item) => item.id === id)
    if (p) p.last_url = url
    if (activeId.value === id) currentUrl.value = url
  })
  unlistenDownloadBlocked = await listen<string>('profile:download-blocked', (event) => {
    ElMessage.warning(`已阻止重复下载：${event.payload}`)
  })
  unlistenStatus = await listen<ProfileStatusEventPayload>('profile:status', (event) => {
    const { id, ...status } = event.payload
    statuses.value = { ...statuses.value, [id]: status }
  })
  unlistenDownload = await listen<DownloadEntry>('profile:download', (event) => {
    const entry = event.payload
    const limit = dlSettings.value?.download_history_limit ?? 200
    downloadHistory.value = [entry, ...downloadHistory.value].slice(0, limit)
    if (entry.success) {
      ElMessage.success(`下载完成：${entry.file_name}`)
    } else {
      ElMessage.error(`下载失败：${entry.file_name}`)
    }
  })

  startAutoRefresh()

  resizeObserver = new ResizeObserver(() => scheduleSyncBounds())
  const el = viewport.value?.element()
  if (el) resizeObserver.observe(el)
})

onBeforeUnmount(() => {
  registerSuppressionHandler(null)
  unlistenNavigation?.()
  unlistenDownloadBlocked?.()
  unlistenStatus?.()
  unlistenDownload?.()
  resizeObserver?.disconnect()
  stopAutoRefresh()
  if (syncBoundsTimer !== undefined) clearTimeout(syncBoundsTimer)
})
</script>

<template>
  <div class="app-shell">
    <ProfileSidebar
      :profiles="filteredProfiles"
      :total="profiles.length"
      :active-id="activeId"
      :open-tabs="openTabs"
      :collapsed="profileSidebarCollapsed"
      v-model:search="searchQuery"
      @toggle="toggleProfileSidebar"
      @open-create="openCreateDialog"
      @open-settings="openSettingsDialog"
      @activate="activateProfile"
      @delete="deleteProfile"
      @clear="clearProfile"
      @reorder="reorderProfiles"
      @move-group="moveProfileToGroup"
      @clone="cloneProfile"
      @test-proxy="testProxy"
    />
    <StatusSidebar
      :profiles="filteredProfiles"
      :statuses="statuses"
      :active-id="activeId"
      :open-tabs="openTabs"
      :collapsed="statusSidebarCollapsed"
      :dl-settings="dlSettings"
      :download-count="downloadHistory.length"
      :show-account="uiPreferences.showStatusAccount"
      :show-proxy="uiPreferences.showStatusProxy"
      :show-updated-time="uiPreferences.showStatusUpdatedTime"
      @toggle="toggleStatusSidebar"
      @activate="activateProfile"
      @refresh="refreshStatuses"
      @save-settings="saveSettings"
      @open-downloads="downloadsVisible = true"
    />
    <main class="main-pane">
      <TabStrip
        :profiles="profiles"
        :open-tabs="openTabs"
        :active-id="activeId"
        :statuses="statuses"
        :show-ai-status="uiPreferences.showTabAiStatus"
        @activate="activateProfile"
        @close="closeTab"
        @create="openCreateDialog"
      />
      <AddressBar
        v-model="currentUrl"
        :disabled="!activeId"
        @navigate="navigate"
        @back="browserAction('back')"
        @forward="browserAction('forward')"
        @reload="browserAction('reload')"
        @account-overview="openAccountOverview"
        @settings="appSettingsVisible = true"
      />
      <div
        class="browser-workspace"
        :class="`dock-${uiPreferences.browserToolbarPosition}`"
      >
        <BrowserViewport ref="viewport" :empty="!activeId" />
        <BrowserActionDock
          v-if="uiPreferences.browserToolbarEnabled"
          :disabled="!activeId"
          :position="uiPreferences.browserToolbarPosition"
          :compact="uiPreferences.browserToolbarCompact"
          :items="uiPreferences.browserToolbarItems"
          :custom-buttons="uiPreferences.customToolbarButtons"
          @back="browserAction('back')"
          @forward="browserAction('forward')"
          @reload="browserAction('reload')"
          @home="goHome"
          @copy-url="copyCurrentUrl"
          @account-overview="openAccountOverview"
          @downloads="downloadsVisible = true"
          @settings="appSettingsVisible = true"
          @custom="openCustomToolbarButton"
        />
      </div>
    </main>
    <AccountOverviewDialog
      v-model="accountOverviewVisible"
      :profiles="profiles"
      :statuses="statuses"
      :history="downloadHistory"
      :active-id="activeId"
      :open-tabs="openTabs"
      @activate="activateProfile"
      @refresh="refreshStatuses"
    />
    <ProfileSettingsDialog
      v-model="profileSettingsVisible"
      :profile="editingProfile"
      :groups="profileGroups"
      @create="createProfile"
      @update="updateProfile"
    />
    <DownloadsDialog
      v-model="downloadsVisible"
      :profiles="profiles"
      :history="downloadHistory"
      :settings="dlSettings"
      :ui-preferences="uiPreferences"
      @cleared="downloadHistory = []"
      @changed="loadDownloadHistory"
      @update-ui="updateUiPreferences"
    />
    <AppPreferencesDialog
      v-model="appSettingsVisible"
      :ui-preferences="uiPreferences"
      :download-settings="dlSettings"
      @save-ui="updateUiPreferences"
      @save-downloads="saveSettings"
    />
  </div>
</template>
